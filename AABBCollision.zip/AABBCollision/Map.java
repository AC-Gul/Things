
/**
 * Write a description of class Map here.
 *
 * @author (Alex Gulewich)
 * @version (Feb, 7, 2021)
 */

//The map designations
public class Map {
    //Each collum is one rectangle
    static int[] x = {0, 0, 0, 475, 0, 26, 250, 115, 0, 80, 120, 160, 180, 200};
    static int[] y = {0, 456, 0, 0, 50, 160, 126, 106, 256, 290, 330, 370, 410, 450};
    static int[] width = {476, 476, 10, 10, 450, 450, 76, 76, 50, 26, 26, 26, 26, 26};
    static int[] height = {10, 10, 456, 466, 10, 10, 36, 60, 20, 10, 10, 10, 10, 10};

}
