At a future date this folder will contain more intricate information.
For now it'll solely store the high score. Which could be modified.
But I kindly ask you not to and to gain it legitimately.